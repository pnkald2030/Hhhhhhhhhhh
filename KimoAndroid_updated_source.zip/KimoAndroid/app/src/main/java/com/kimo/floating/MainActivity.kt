package com.kimo.floating

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("kimo_settings", MODE_PRIVATE) }
    private var pendingVideo: Uri? = null
    private var running = false
    private var page = "home"
    private var instructionsExpanded = false
    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { pendingVideo = uri; launchWhenAllowed() }
    }

    private val dark get() = prefs.getBoolean("dark", true)
    private val english get() = prefs.getBoolean("english", false)
    private fun tr(ar: String, en: String) = if (english) en else ar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        running = prefs.getBoolean("running", false)
        render()
    }

    private fun render() {
        val bg = if (dark) Color.rgb(16,20,25) else Color.rgb(246,248,248)
        val fg = if (dark) Color.WHITE else Color.rgb(28,38,40)
        window.statusBarColor = Color.rgb(23,72,63)
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (english) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(bg)
        }
        if (page == "home") {
            val banner = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(5), dp(14), dp(5))
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(Color.rgb(23,72,63), Color.rgb(40,115,108), Color.rgb(82,111,121)))
            }
            val gear = text("⚙", 23, Color.WHITE).apply {
                gravity = Gravity.CENTER
                setOnClickListener { page = "settings"; render() }
            }
            banner.addView(gear, LinearLayout.LayoutParams(dp(42), -1))
            val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            titleCol.addView(text("كيمو", 20, Color.WHITE, true).apply { gravity = Gravity.CENTER })
            titleCol.addView(text(tr("نافذة لمشاهدة الفيديو فوق التطبيقات الأخرى.","Watch video above other apps."), 10, 0xffd1dcda.toInt()).apply { gravity = Gravity.CENTER })
            banner.addView(titleCol, LinearLayout.LayoutParams(0, -1, 1f))
            banner.addView(View(this), LinearLayout.LayoutParams(dp(42), 1))
            root.addView(banner, LinearLayout.LayoutParams(-1, dp(58)))
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(14), dp(18), dp(18))
            }
            content.addView(section(tr("حالة التطبيق","App status")))
            val toggle = text(if (running) tr("إضغط للإيقاف","Tap to stop") else tr("إضغط لتشغيل","Tap to start"),
                16, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = rounded(if (running) 0xff397b61.toInt() else 0xffa94f55.toInt(), 18)
                setOnClickListener {
                    if (running) {
                        stopService(Intent(this@MainActivity, FloatingVideoService::class.java))
                        running = false
                        prefs.edit().putBoolean("running", false).apply()
                        render()
                    } else {
                        pickVideo.launch("video/*")
                    }
                }
            }
            content.addView(toggle, LinearLayout.LayoutParams(-1, dp(50)))
            content.addView(section(tr("الأذونات","Permissions"), tr("أذونات ضرورية لتشغيل التطبيق","Required to run the app")))
            content.addView(option(tr("الظهور فوق التطبيقات","Display over other apps")) {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            content.addView(option(tr("العمل في الخلفية","Background activity")) {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {}
            })
            content.addView(section(tr("شكل النافذة","Window shape"), tr("اختر طريقة عرض الفيديو داخل النافذة","Choose how video appears in the window")))
            content.addView(option(tr("1- طولي دائماً","1- Always portrait"), tr("نافذة طولية","Portrait window")) {
                prefs.edit().putBoolean("adaptive", false).apply()
            })
            content.addView(option(tr("2- تكيفي تلقائي","2- Adaptive"), tr("حسب أبعاد الفيديو","Based on video dimensions")) {
                prefs.edit().putBoolean("adaptive", true).apply()
            })
            content.addView(option(tr("اختيار فيديو من الهاتف","Choose a video from your phone")) { pickVideo.launch("video/*") })
            val note = text(tr("يدعم الإصدار الحالي تشغيل الملفات المحلية. التحكم المباشر بفيديوهات التطبيقات الأخرى يعتمد على دعم التطبيق المصدر ونظام أندرويد.",
                "This version plays local files. Controlling videos in other apps depends on source-app and Android support."), 11,
                if (dark) 0xff9ba8ad.toInt() else 0xff667477.toInt())
            note.setPadding(0, dp(14), 0, 0)
            content.addView(note)
            root.addView(ScrollView(this).apply { isFillViewport=true; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(12), dp(18), dp(20))
            }
            val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            header.addView(text(tr(if (page=="settings") "الإعدادات" else "التعليمات", if (page=="settings") "Settings" else "Instructions"), 21, fg, true), LinearLayout.LayoutParams(0, dp(48), 1f))
            header.addView(text("‹", 30, fg).apply { gravity=Gravity.CENTER; setOnClickListener { page=if(page=="instructions") "settings" else "home"; render() } }, LinearLayout.LayoutParams(dp(44), dp(48)))
            content.addView(header)
            if (page == "settings") {
                content.addView(option(tr("لغة التطبيق","App language"), if (english) "عربي" else "English") {
                    prefs.edit().putBoolean("english", !english).apply(); render()
                })
                content.addView(option(tr("الوضع المعتم","Dark mode"), if (dark) tr("مفعّل","On") else tr("متوقف","Off")) {
                    prefs.edit().putBoolean("dark", !dark).apply(); render()
                })
                content.addView(section(tr("المساعدة والمعلومات","Help and information")))
                content.addView(option(tr("أذونات التطبيق","App permissions")) { page="home"; render() })
                content.addView(option(tr("التعليمات","Instructions")) { page="instructions"; instructionsExpanded=true; render() })
                content.addView(option(tr("سياسة الخصوصية والإصدار","Privacy policy and version"), "0.1.0-prototype") {
                    showInfo(tr("سياسة الخصوصية","Privacy policy"),
                        tr("يعالج كيمو ملف الفيديو الذي تختاره محلياً لتشغيله في النافذة العائمة. لا تتضمن هذه النسخة سياسة منشورة أو مراجعة نهائية لجمع البيانات. يجب مراجعة ذلك قبل النشر.",
                           "Kimo processes the video file you select locally for floating playback. This prototype has no finalized published privacy policy or data-collection review. This must be completed before release."))
                })
                content.addView(option(tr("الدعم الفني","Technical support")) { openWhatsApp("نسعد بتواصلكم معنا ماهي مشكلتك؟") })
                content.addView(option(tr("المطوّر: كيمو","Developer: Kimo"), tr("اضغط للتواصل مع المطوّر","Tap to contact developer")) { openWhatsApp("") })
                content.addView(text("© 2026 كيمو. جميع الحقوق محفوظة.", 10, 0xff8b969b.toInt()).apply { setPadding(0, dp(18), 0, 0) })
            } else {
                content.addView(option(tr("تشغيل كيمو","Start Kimo")) {
                    showInfo(tr("تشغيل كيمو","Start Kimo"), tr("امنح إذن الظهور فوق التطبيقات، واسمح بالعمل في الخلفية عند الحاجة، ثم اختر ملف فيديو من الهاتف لتشغيله في نافذة عائمة.",
                        "Grant display-over-other-apps permission, allow background activity if needed, then choose a video stored on your phone."))
                })
                content.addView(option(tr("الوضع المظلم","Dark mode")) {
                    showInfo(tr("الوضع المظلم","Dark mode"), tr("يمكنك تفعيل الوضع المعتم أو إيقافه من صفحة الإعدادات.","Toggle dark mode from Settings."))
                })
                content.addView(option(tr("تغيير اللغة","Change language")) {
                    showInfo(tr("تغيير اللغة","Change language"), tr("افتح الإعدادات واضغط خانة لغة التطبيق للتبديل بين العربية والإنجليزية.","Open Settings and tap App language to switch between Arabic and English."))
                })
                content.addView(option(tr("استخدام النافذة العائمة","Use floating window")) {
                    showInfo(tr("استخدام النافذة العائمة","Use floating window"), tr("اختر فيديو محلياً. يمكنك سحب النافذة وتغيير حجمها بإصبعين. اضغط × لإغلاقها. لا يدعم هذا النموذج التحكم المباشر في تطبيقات الفيديو الأخرى.",
                        "Choose a local video. Drag the window and resize it with two fingers. Tap × to close. This prototype does not directly control other video apps."))
                })
            }
            root.addView(ScrollView(this).apply { isFillViewport=true; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
    }

    private fun section(title: String, hint: String? = null): View {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0, dp(17), 0, dp(8)) }
        box.addView(text(title, 16, if(dark) Color.WHITE else 0xff263538.toInt(), true))
        if (hint != null) box.addView(text(hint, 10, 0xff89969a.toInt()))
        return box
    }
    private fun option(label: String, hint: String? = null, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background=rounded(if(dark) 0xff202a30.toInt() else 0xffe9eeee.toInt(), 16)
            setOnClickListener { action() }
        }
        box.addView(text(label, 14, if(dark) Color.WHITE else 0xff263538.toInt()))
        if (hint != null) box.addView(text(hint, 10, 0xff89969a.toInt()))
        val lp=LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=dp(8)
        box.layoutParams=lp
        return box
    }
    private fun text(value: String, size: Int, color: Int, bold: Boolean=false) = TextView(this).apply {
        text=value; textSize=size.toFloat(); setTextColor(color)
        if(bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius=dp(radius).toFloat()
    }
    private fun showInfo(title: String, message: String) =
        android.app.AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show()
    private fun openWhatsApp(message: String) {
        val url = "https://wa.me/967771594022" + if(message.isNotEmpty()) "?text="+Uri.encode(message) else ""
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
    }
    private fun launchWhenAllowed() {
        val uri=pendingVideo ?: return
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        val i=Intent(this, FloatingVideoService::class.java).apply { data=uri }
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
        pendingVideo=null
        running=true; prefs.edit().putBoolean("running",true).apply(); render()
    }
    override fun onResume() {
        super.onResume()
        if(pendingVideo!=null && (Build.VERSION.SDK_INT<23 || Settings.canDrawOverlays(this))) launchWhenAllowed()
    }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        when(page) {
            "instructions" -> { page="settings"; render() }
            "settings" -> { page="home"; render() }
            else -> android.app.AlertDialog.Builder(this).setMessage(tr("هل تريد الخروج من كيمو؟","Exit Kimo?"))
                .setNegativeButton(tr("إلغاء","Cancel"),null)
                .setPositiveButton(tr("خروج","Exit")) { _,_-> finish() }.show()
        }
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
