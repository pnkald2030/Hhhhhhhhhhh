package com.kimo.floating

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class FloatingVideoService : Service() {
    private lateinit var wm: WindowManager
    private var player: ExoPlayer? = null
    private var root: FrameLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var endControls: LinearLayout? = null
    private val prefs by lazy { getSharedPreferences("kimo_playback", Context.MODE_PRIVATE) }
    private var startX = 0f; private var startY = 0f
    private var baseX = 0; private var baseY = 0
    private var pinchDistance = 0f; private var baseWidth = 0; private var baseHeight = 0

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(41, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val uri = intent?.data ?: return START_NOT_STICKY
        showPlayer(uri)
        return START_NOT_STICKY
    }

    private fun showPlayer(uri: Uri) {
        removeOverlay()
        val density = resources.displayMetrics.density
        val width = (300 * density).toInt()
        val height = (480 * density).toInt()
        val frame = FrameLayout(this).apply { setBackgroundColor(0xff111820.toInt()) }
        val pv = PlayerView(this).apply { useController = false; resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT }
        frame.addView(pv, FrameLayout.LayoutParams(-1, -1))
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12)
            visibility = View.GONE
        }
        controls.addView(control("◀|", "السابق") { }.apply { isEnabled = false; alpha = 0.35f })
        controls.addView(control("⟳", "إعادة") { player?.seekTo(0); player?.play(); controls.visibility = View.GONE })
        controls.addView(control("|▶", "التالي") { }.apply { isEnabled = false; alpha = 0.35f })
        val overlayControls = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER)
        frame.addView(controls, overlayControls)
        endControls = controls
        val close = TextView(this).apply {
            text = "×"
            textSize = 28f
            setTextColor(0xffffffff.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 4, 12, 4)
            setOnClickListener { stopSelf() }
        }
        frame.addView(close, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.END))

        val exo = ExoPlayer.Builder(this).build()
        player = exo
        pv.player = exo
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        val saved = prefs.getLong(uri.toString(), 0L)
        if (saved > 0) exo.seekTo(saved)
        exo.playWhenReady = true
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) controls.visibility = View.VISIBLE
            }
        })

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels - width) / 2
            y = (100 * density).toInt()
        }
        params = lp
        pv.setOnTouchListener { _, event -> handleTouch(event) }
        root = frame
        try { wm.addView(frame, lp) } catch (_: Exception) { stopSelf() }
    }

    private fun control(symbol: String, label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = symbol
        contentDescription = label
        textSize = 23f
        setTextColor(0xffffffff.toInt())
        gravity = Gravity.CENTER
        setPadding(18, 12, 18, 12)
        setOnClickListener { action() }
    }

    private fun handleTouch(e: MotionEvent): Boolean {
        val lp = params ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { startX=e.rawX; startY=e.rawY; baseX=lp.x; baseY=lp.y; return true }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount >= 2) { pinchDistance=distance(e); baseWidth=lp.width; baseHeight=lp.height }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2 && pinchDistance > 0) {
                    val scale = distance(e) / pinchDistance
                    val w = (baseWidth * scale).toInt().coerceIn(dp(190), dp(430))
                    val h = (baseHeight * scale).toInt().coerceIn(dp(260), dp(700))
                    lp.width=w; lp.height=h
                } else {
                    lp.x = baseX + (e.rawX-startX).toInt()
                    lp.y = baseY + (e.rawY-startY).toInt()
                }
                clamp(lp)
                try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> { pinchDistance=0f; return true }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pinchDistance=0f; return true }
        }
        return true
    }

    private fun clamp(lp: WindowManager.LayoutParams) {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, max(0, dm.widthPixels-lp.width))
        val topSafe = (28 * dm.density).toInt()
        val bottomSafe = (48 * dm.density).toInt()
        lp.y = lp.y.coerceIn(topSafe, max(topSafe, dm.heightPixels-bottomSafe-lp.height))
    }
    private fun distance(e: MotionEvent): Float {
        if (e.pointerCount < 2) return 0f
        val dx=e.getX(0)-e.getX(1); val dy=e.getY(0)-e.getY(1)
        return kotlin.math.sqrt(dx*dx+dy*dy)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun removeOverlay() {
        val uri = player?.currentMediaItem?.localConfiguration?.uri?.toString()
        if (uri != null) prefs.edit().putLong(uri, player?.currentPosition ?: 0L).apply()
        try { root?.let { wm.removeView(it) } } catch (_: Exception) {}
        root=null
        player?.release(); player=null
    }

    override fun onDestroy() { removeOverlay(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("kimo_playback", "تشغيل كيمو", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification() = NotificationCompat.Builder(this, "kimo_playback")
        .setSmallIcon(android.R.drawable.ic_media_play)
        .setContentTitle("كيمو يعمل")
        .setContentText("مشغل الفيديو العائم قيد التشغيل")
        .setOngoing(true)
        .build()
}
