package com.kimo.floating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private var pendingVideo: Uri? = null
    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            pendingVideo = uri
            launchWhenAllowed()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(23,72,63)
        window.navigationBarColor = Color.rgb(16,20,25)
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
            setBackgroundColor(Color.rgb(16,20,25))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val banner = TextView(this).apply {
            text = "كيمو\nنافذة لمشاهدة الفيديو فوق التطبيقات الأخرى"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(40,115,108))
        }
        root.addView(banner, LinearLayout.LayoutParams(-1, dp(76)))
        val title = TextView(this).apply {
            text = "حالة التطبيق"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, dp(28), 0, dp(12))
        }
        root.addView(title)
        val status = TextView(this).apply {
            text = "كيمو جاهز لاختيار فيديو محفوظ على الهاتف"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(14), dp(10), dp(14))
        }
        root.addView(status)
        val choose = Button(this).apply {
            text = "اختر فيديو وشغّله في نافذة عائمة"
            textSize = 15f
            setOnClickListener { pickVideo.launch("video/*") }
        }
        root.addView(choose, LinearLayout.LayoutParams(-1, dp(54)))
        val permission = Button(this).apply {
            text = "إعداد إذن الظهور فوق التطبيقات"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        }
        val p = LinearLayout.LayoutParams(-1, dp(50)); p.topMargin = dp(12)
        root.addView(permission, p)
        val note = TextView(this).apply {
            text = "هذه نسخة أولية لتشغيل ملفات الفيديو المحلية. دعم التحكم المباشر في فيديوهات التطبيقات الأخرى مثل YouTube وTikTok وReels يحتاج اختبارات وتكاملاً منفصلاً، ولا يمكن ضمانه على جميع الأجهزة."
            textSize = 12f
            setTextColor(Color.rgb(160,170,180))
            setPadding(0, dp(22), 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun launchWhenAllowed() {
        val uri = pendingVideo ?: return
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, FloatingVideoService::class.java).apply { data = uri }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        pendingVideo = null
    }

    override fun onResume() {
        super.onResume()
        if (pendingVideo != null && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) launchWhenAllowed()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
